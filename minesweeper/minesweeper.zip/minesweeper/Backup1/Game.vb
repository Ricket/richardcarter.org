'Minesweeper
'By Ricky Carter
'Last modified 10-12-05
'See About box (About.vb) for class information.

Public Class frmGame
    Inherits System.Windows.Forms.Form


#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        theTimer = New Timer
        theTimer.Interval = 1000
        theBoard = New GameBoard(Me, 0)

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem5 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem8 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem11 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem13 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem14 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem15 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem16 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem17 As System.Windows.Forms.MenuItem
    Friend WithEvents StatusBar1 As System.Windows.Forms.StatusBar
    Friend WithEvents StatusBarPanel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents StatusBarPanel2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents MenuItem12 As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmGame))
        Me.MainMenu1 = New System.Windows.Forms.MainMenu
        Me.MenuItem1 = New System.Windows.Forms.MenuItem
        Me.MenuItem3 = New System.Windows.Forms.MenuItem
        Me.MenuItem2 = New System.Windows.Forms.MenuItem
        Me.MenuItem6 = New System.Windows.Forms.MenuItem
        Me.MenuItem7 = New System.Windows.Forms.MenuItem
        Me.MenuItem8 = New System.Windows.Forms.MenuItem
        Me.MenuItem9 = New System.Windows.Forms.MenuItem
        Me.MenuItem10 = New System.Windows.Forms.MenuItem
        Me.MenuItem11 = New System.Windows.Forms.MenuItem
        Me.MenuItem13 = New System.Windows.Forms.MenuItem
        Me.MenuItem14 = New System.Windows.Forms.MenuItem
        Me.MenuItem15 = New System.Windows.Forms.MenuItem
        Me.MenuItem17 = New System.Windows.Forms.MenuItem
        Me.MenuItem16 = New System.Windows.Forms.MenuItem
        Me.MenuItem4 = New System.Windows.Forms.MenuItem
        Me.MenuItem12 = New System.Windows.Forms.MenuItem
        Me.MenuItem5 = New System.Windows.Forms.MenuItem
        Me.StatusBar1 = New System.Windows.Forms.StatusBar
        Me.StatusBarPanel1 = New System.Windows.Forms.StatusBarPanel
        Me.StatusBarPanel2 = New System.Windows.Forms.StatusBarPanel
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StatusBarPanel2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem4})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem3, Me.MenuItem2, Me.MenuItem6, Me.MenuItem7, Me.MenuItem8, Me.MenuItem9, Me.MenuItem10, Me.MenuItem11, Me.MenuItem13, Me.MenuItem14, Me.MenuItem15, Me.MenuItem17, Me.MenuItem16})
        Me.MenuItem1.Text = "Game"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 0
        Me.MenuItem3.Shortcut = System.Windows.Forms.Shortcut.F2
        Me.MenuItem3.Text = "New"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.Text = "-"
        '
        'MenuItem6
        '
        Me.MenuItem6.Checked = True
        Me.MenuItem6.Index = 2
        Me.MenuItem6.Text = "Beginner"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 3
        Me.MenuItem7.Text = "Intermediate"
        '
        'MenuItem8
        '
        Me.MenuItem8.Index = 4
        Me.MenuItem8.Text = "Expert"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 5
        Me.MenuItem9.Text = "Custom..."
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 6
        Me.MenuItem10.Text = "-"
        '
        'MenuItem11
        '
        Me.MenuItem11.Enabled = False
        Me.MenuItem11.Index = 7
        Me.MenuItem11.Text = "Marks (?)"
        '
        'MenuItem13
        '
        Me.MenuItem13.Enabled = False
        Me.MenuItem13.Index = 8
        Me.MenuItem13.Text = "Sound"
        '
        'MenuItem14
        '
        Me.MenuItem14.Index = 9
        Me.MenuItem14.Text = "-"
        '
        'MenuItem15
        '
        Me.MenuItem15.Enabled = False
        Me.MenuItem15.Index = 10
        Me.MenuItem15.Text = "Best Times..."
        '
        'MenuItem17
        '
        Me.MenuItem17.Index = 11
        Me.MenuItem17.Text = "-"
        '
        'MenuItem16
        '
        Me.MenuItem16.Index = 12
        Me.MenuItem16.Text = "Exit"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 1
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem12, Me.MenuItem5})
        Me.MenuItem4.Text = "Help"
        '
        'MenuItem12
        '
        Me.MenuItem12.Index = 0
        Me.MenuItem12.Shortcut = System.Windows.Forms.Shortcut.F1
        Me.MenuItem12.Text = "Help"
        '
        'MenuItem5
        '
        Me.MenuItem5.Index = 1
        Me.MenuItem5.Text = "About"
        '
        'StatusBar1
        '
        Me.StatusBar1.Location = New System.Drawing.Point(0, 217)
        Me.StatusBar1.Name = "StatusBar1"
        Me.StatusBar1.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.StatusBarPanel1, Me.StatusBarPanel2})
        Me.StatusBar1.ShowPanels = True
        Me.StatusBar1.Size = New System.Drawing.Size(234, 16)
        Me.StatusBar1.SizingGrip = False
        Me.StatusBar1.TabIndex = 0
        '
        'StatusBarPanel1
        '
        Me.StatusBarPanel1.ToolTipText = "Bombs Left"
        '
        'StatusBarPanel2
        '
        Me.StatusBarPanel2.ToolTipText = "Timer"
        '
        'frmGame
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(6, 16)
        Me.ClientSize = New System.Drawing.Size(234, 233)
        Me.Controls.Add(Me.StatusBar1)
        Me.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Menu = Me.MainMenu1
        Me.Name = "frmGame"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Minesweeper"
        CType(Me.StatusBarPanel1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StatusBarPanel2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Public theBoard As GameBoard
    Public WithEvents theTimer As System.Windows.Forms.Timer
    Public timerCount As Integer

    Private Sub MenuItem16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem16.Click
        'Game>Exit
        End
    End Sub

    Private Sub MenuItem5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem5.Click
        'Help>About
        Dim varAboutWin As frmAbout
        varAboutWin = New frmAbout
        varAboutWin.Show()
    End Sub

    Private Sub MenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem3.Click
        'Game>New
        AutoNew()
    End Sub

    Public Sub AutoNew()
        Dim tempDiff As Integer
        If MenuItem6.Checked = True Then
            tempDiff = 0
        End If
        If MenuItem7.Checked = True Then
            tempDiff = 1
        End If
        If MenuItem8.Checked = True Then
            tempDiff = 2
        End If
        If MenuItem9.Checked = True Then
            tempDiff = 3
        End If
        Dim tempWidth As Integer
        Dim tempHeight As Integer
        Dim tempBombs As Integer
        If (tempDiff = 3) Then
            tempWidth = theBoard.customWidth
            tempHeight = theBoard.customHeight
            tempBombs = theBoard.customBombs
        End If
        theBoard.ClearAll()
        theBoard.Dispose()
        If (tempDiff = 3) Then
            theBoard = New GameBoard(Me, 3, tempWidth, tempHeight, tempBombs)
        Else
            theBoard = New GameBoard(Me, tempDiff)
        End If
    End Sub

    Private Sub MenuItem6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem6.Click
        'Game>Beginner
        MenuItem6.Checked = True
        MenuItem7.Checked = False
        MenuItem8.Checked = False
        MenuItem9.Checked = False
        theBoard.ClearAll()
        theBoard.Dispose()
        theBoard = New GameBoard(Me, 0)
    End Sub

    Private Sub MenuItem7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem7.Click
        'Game>Intermediate
        MenuItem6.Checked = False
        MenuItem7.Checked = True
        MenuItem8.Checked = False
        MenuItem9.Checked = False
        theBoard.ClearAll()
        theBoard.Dispose()
        theBoard = New GameBoard(Me, 1)
    End Sub

    Private Sub MenuItem8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem8.Click
        'Game>Expert
        MenuItem6.Checked = False
        MenuItem7.Checked = False
        MenuItem8.Checked = True
        MenuItem9.Checked = False
        theBoard.ClearAll()
        theBoard.Dispose()
        theBoard = New GameBoard(Me, 2)
    End Sub

    Public Function GetGameBoard() As GameBoard
        Return theBoard
    End Function

    Private Sub MenuItem9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem9.Click
        'Game>Custom...
        Dim tempCustomForm As New CustomOptions
        tempCustomForm.SetParent(Me)
        tempCustomForm.SetValues(theBoard.gameButtons.GetLength(0), theBoard.gameButtons.GetLength(1), theBoard.GetNumBombs())
        tempCustomForm.Show()
    End Sub

    Public Sub DoCustom(ByVal width As Integer, ByVal height As Integer, ByVal numBombs As Integer)
        MenuItem6.Checked = False
        MenuItem7.Checked = False
        MenuItem8.Checked = False
        MenuItem9.Checked = True
        theBoard.ClearAll()
        theBoard.Dispose()
        theBoard = New GameBoard(Me, 3, width, height, numBombs)
    End Sub

    Public Sub DoGameOver()
        'After it's game over, all bombs are auto-uncovered, clicking is
        'disabled, and this sub is run.
        'Do things such as display game over, add hi scores, etc. to here.
        theTimer.Stop()
        MessageBox.Show("Game Over!", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

    Public Sub DoWon()
        'If the user wins, clicking is disabled, and this sub is run.
        'Do things such as display "you won", add hi scores, etc. to here.
        theTimer.Stop()
        theBoard.firstClick = False
        MessageBox.Show("You won!", "Winner", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
    End Sub

    Public Sub TimerIncrement(ByVal sender As Object, ByVal e As System.EventArgs) Handles theTimer.Tick
        timerCount = timerCount + 1
        StatusBarPanel2.Text = timerCount
    End Sub

    Private Sub MenuItem12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem12.Click
        Dim tempHelpForm As New Help
        tempHelpForm.Show()
    End Sub
End Class

Public Class GameBoard
    Implements IDisposable

    Private difficulty As Integer
    Public gameButtons(8, 8) As GameButton '2d array for storing the buttons
    Private parentForm As frmGame  'the current frmGame instance
    Public customWidth As Integer
    Public customHeight As Integer
    Public customBombs As Integer
    Public numBombs As Integer
    Public timerRunning As Boolean = False
    Public gameOver As Boolean = False
    Public score As Integer
    Public firstClick As Boolean = False
    Public marks As Boolean = True

    Public Sub New(ByVal theForm As frmGame, ByVal diffLevel As Integer, Optional ByVal widthh As Integer = -1, Optional ByVal heightt As Integer = -1, Optional ByVal bombss As Integer = -1)
        'diffLevel is the difficulty
        '0 is easy, 1 is medium, 2 is hard, 3 is custom (but not used here)
        parentForm = theForm
        difficulty = diffLevel
        If (diffLevel = 3) Then
            If (widthh <> -1) Then
                customWidth = widthh
            End If
            If (heightt <> -1) Then
                customHeight = heightt
            End If
            If (bombss <> -1) Then
                customBombs = bombss
            End If
        End If
        SetUpButtons()
    End Sub

    Public Sub Reset(ByVal diffLevel As Integer)
        difficulty = diffLevel
        SetUpButtons()
    End Sub

    Public Sub SetUpButtons()
        'Should be called when difficulty changes + new is pressed
        'ReDims the buttons based on difficulty
        'and initializes them
        parentForm.SuspendLayout()
        gameOver = False
        If (difficulty = 0) Then
            ReDim gameButtons(8, 8)
        End If
        If (difficulty = 1) Then
            ReDim gameButtons(15, 15)
        End If
        If (difficulty = 2) Then
            ReDim gameButtons(29, 15)
        End If
        If (difficulty = 3) Then
            ReDim gameButtons(customWidth - 1, customHeight - 1)
        End If

        Dim x1 As Integer
        Dim y1 As Integer
        'Perform the new function for every var in the array
        For x1 = 0 To gameButtons.GetLength(0) - 1
            For y1 = 0 To gameButtons.GetLength(1) - 1
                gameButtons(x1, y1) = New GameButton(parentForm, x1, y1)
            Next
        Next
        parentForm.Width = (gameButtons.GetLength(0) * 24) + 24
        parentForm.Height = (gameButtons.GetLength(1) * 24) + 78
        parentForm.StatusBarPanel1.Width = (parentForm.Width - 6) / 2
        parentForm.StatusBarPanel2.Width = (parentForm.Width - 6) / 2

        'Add bombs, based on difficulty
        Select Case difficulty
            Case 0
                AddBombs(10)
                parentForm.StatusBarPanel1.Text = "10"
            Case 1
                AddBombs(40)
                parentForm.StatusBarPanel1.Text = "40"
            Case 2
                AddBombs(99)
                parentForm.StatusBarPanel1.Text = "99"
            Case 3
                AddBombs(customBombs)
                parentForm.StatusBarPanel1.Text = CType(customBombs, String)
        End Select
        'Add numbers to non-bomb spaces
        MakeNumbers()
        parentForm.timerCount = 0
        parentForm.StatusBarPanel2.Text = "0"
        Me.firstClick = False
        parentForm.ResumeLayout()
    End Sub

    Public Function GetNumBombs() As Integer
        Select Case difficulty
            Case 0
                Return 10
            Case 1
                Return 40
            Case 2
                Return 99
            Case 3
                Return customBombs
        End Select
    End Function

    Private Sub AddBombs(ByVal numBombs As Integer)
        'Adds numBombs number of bombs randomly to the board
        Dim randomizer As New Random
        Dim i As Integer
        Dim j As Integer
        Dim k As Integer
        For i = 1 To numBombs
            j = Decimal.op_Modulus(randomizer.Next(), gameButtons.GetLength(0))
            k = Decimal.op_Modulus(randomizer.Next(), gameButtons.GetLength(1))
            If (gameButtons(j, k).bomb = False) Then
                gameButtons(j, k).SetBomb()
            Else
                i = i - 1
            End If
        Next
        Me.numBombs = numBombs
        Me.score = numBombs
    End Sub

    Private Sub MakeNumbers()
        'Adds numbers to non-bomb spaces, by calculating
        'adjacent bombs for each space.
        'If there are 0 bombs, the gameButtons.SetNumber()
        'handles it as a blank button
        Dim x As Integer
        Dim y As Integer
        For x = 0 To gameButtons.GetLength(0) - 1
            For y = 0 To gameButtons.GetLength(1) - 1
                If gameButtons(x, y).bomb = False Then
                    'Its not a bomb, so check for bombs around it
                    Dim bombNumberTemp As Integer = 0
                    If (x > 0) Then
                        If gameButtons(x - 1, y).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (x < gameButtons.GetLength(0) - 1) Then
                        If gameButtons(x + 1, y).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (x > 0) And (y > 0) Then
                        If gameButtons(x - 1, y - 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (x < gameButtons.GetLength(0) - 1) And (y > 0) Then
                        If gameButtons(x + 1, y - 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (x > 0) And (y < gameButtons.GetLength(1) - 1) Then
                        If gameButtons(x - 1, y + 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (x < gameButtons.GetLength(0) - 1) And (y < gameButtons.GetLength(1) - 1) Then
                        If gameButtons(x + 1, y + 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (y > 0) Then
                        If gameButtons(x, y - 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    If (y < gameButtons.GetLength(1) - 1) Then
                        If gameButtons(x, y + 1).bomb = True Then
                            bombNumberTemp = bombNumberTemp + 1
                        End If
                    End If
                    gameButtons(x, y).SetNumber(bombNumberTemp)
                End If
            Next
        Next
    End Sub

    Protected Overrides Sub Finalize()
        MyBase.Finalize()
        ClearAll()
    End Sub

    Public Sub ClearAll()
        parentForm.SuspendLayout()
        Dim x As Integer
        Dim y As Integer
        For x = 0 To gameButtons.GetLength(0) - 1
            For y = 0 To gameButtons.GetLength(1) - 1
                gameButtons(x, y).Clear()
                gameButtons(x, y).Dispose()
            Next
        Next
        parentForm.ResumeLayout()
    End Sub

    Public Sub Dispose() Implements System.IDisposable.Dispose
        'Clears the buttons as it's disposed
        ClearAll()
    End Sub

    Public Sub UncoverNearby(ByVal x As Integer, ByVal y As Integer, Optional ByVal recursed As Boolean = False)
        'If the space at x,y is 0, uncover all 0's and adjacent
        'numbers, as a chain reaction.
        'Run the Windows Minesweeper to see what I mean.
        If (gameButtons(x, y).GetNumber() > 0) Then
            If (recursed = True) Then
                'This has been triggered from recursing, and is a 0. Uncover and stop.
                gameButtons(x, y).Uncover()
            End If
            'This is the first call, and it's not a 0. Just stop.
        Else
            'Number is 0, start/continue the chain reaction.
            'Note that this is a recursive function.
            If (gameButtons(x, y).bomb = False) Then
                gameButtons(x, y).Uncover()
                If (x > 0) Then
                    If (gameButtons(x - 1, y).AlreadyUncovered() = False) Then
                        UncoverNearby(x - 1, y, True)
                    End If
                End If
                If (x < gameButtons.GetLength(0) - 1) Then
                    If (gameButtons(x + 1, y).AlreadyUncovered() = False) Then
                        UncoverNearby(x + 1, y, True)
                    End If
                End If
                If (y > 0) Then
                    If (gameButtons(x, y - 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x, y - 1, True)
                    End If
                End If
                If (y < gameButtons.GetLength(1) - 1) Then
                    If (gameButtons(x, y + 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x, y + 1, True)
                    End If
                End If
                If (x > 0) And (y > 0) Then
                    If (gameButtons(x - 1, y - 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x - 1, y - 1, True)
                    End If
                End If
                If (x > 0) And (y < gameButtons.GetLength(1) - 1) Then
                    If (gameButtons(x - 1, y + 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x - 1, y + 1, True)
                    End If
                End If
                If (x < gameButtons.GetLength(0) - 1) And (y > 0) Then
                    If (gameButtons(x + 1, y - 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x + 1, y - 1, True)
                    End If
                End If
                If (x < gameButtons.GetLength(0) - 1) And (y < gameButtons.GetLength(1) - 1) Then
                    If (gameButtons(x + 1, y + 1).AlreadyUncovered() = False) Then
                        UncoverNearby(x + 1, y + 1, True)
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub UncoverAllBombs()
        Dim x As Integer
        Dim y As Integer
        For x = 0 To gameButtons.GetLength(0) - 1
            For y = 0 To gameButtons.GetLength(1) - 1
                If (gameButtons(x, y).bomb = True) Or (gameButtons(x, y).flagged = True) Then
                    gameButtons(x, y).Uncover(True)
                End If
            Next
        Next
    End Sub

    Public Sub CheckBombs()
        parentForm.StatusBarPanel1.Text = CType(score, String)
        Dim x As Integer
        Dim y As Integer
        numBombs = 0
        For x = 0 To gameButtons.GetLength(0) - 1
            For y = 0 To gameButtons.GetLength(1) - 1
                If (gameButtons(x, y).bomb = True) And (gameButtons(x, y).flagged = False) Then
                    numBombs = numBombs + 1
                End If
            Next
        Next
        If (numBombs = 0) Then
            CheckAllSpaces()
        End If
    End Sub

    Public Sub CheckAllSpaces()
        'Check to see if all spaces are clicked in or are a bomb, if so then
        'do won.
        Dim x As Integer
        Dim y As Integer
        Dim numSpaces As Integer = 0
        For x = 0 To gameButtons.GetLength(0) - 1
            For y = 0 To gameButtons.GetLength(1) - 1
                If (gameButtons(x, y).FlatStyle = FlatStyle.Flat) Or (gameButtons(x, y).bomb = True) Then
                    numSpaces = numSpaces + 1
                End If
            Next
        Next
        If (numSpaces = (gameButtons.GetLength(0) * gameButtons.GetLength(1))) Then
            gameOver = True
            parentForm.DoWon()
        End If
    End Sub
End Class
'End of class GameBoard

Public Class GameButton
    Inherits System.Windows.Forms.Button
    '^Notice this!! It's a button with more Subs!

    Public bomb As Boolean = False
    Public flagged As Boolean = False
    Public thisNumber As Integer = 0
    Private parentForm As frmGame
    Private x As Integer
    Private y As Integer
    Public resetOnMouseUp As Boolean = False

    Public Sub SetBomb()
        'Mark this as a bomb. Simple enough :)
        bomb = True
        thisNumber = -1
    End Sub

    Public Function GetNumber() As Integer
        'Returns this button's number, which should be -1 for bombs.
        Return thisNumber
    End Function

    Public Sub Uncover(Optional ByVal isUncovering As Boolean = False)
        '"Uncovers" the button
        'On click, run this function
        'Changes style to look like pressed in, then
        'adds the value - "X" for bomb, number for the button
        Me.FlatStyle = FlatStyle.Flat
        Me.BackColor = System.Drawing.Color.Empty
        Me.ForeColor = System.Drawing.Color.Empty
        If (bomb = False) Then
            If (thisNumber = 0) Then
                Me.Text = " "
            Else
                Me.Text = thisNumber
            End If
            Me.BackColor = System.Drawing.Color.White
            If (isUncovering = True) Then
                If (flagged = True) Then
                    Me.Text = "X"
                    Me.ForeColor = System.Drawing.Color.White
                    Me.BackColor = System.Drawing.Color.Violet
                End If
            Else
                parentForm.GetGameBoard().CheckBombs()
            End If
        Else
            Me.Text = "X"
            Me.ForeColor = System.Drawing.Color.Red
            Me.BackColor = System.Drawing.Color.Black
            parentForm.GetGameBoard().gameOver = True
            If (isUncovering = False) Then
                parentForm.GetGameBoard().UncoverAllBombs()
                parentForm.DoGameOver()
            End If
        End If
    End Sub

    Public Function AlreadyUncovered() As Boolean
        If (Me.FlatStyle = FlatStyle.Flat) Then
            Return True
        Else
            Return False
        End If
    End Function

    Public Sub SetNumber(ByVal theNum As Integer)
        'Sets this button as the number
        thisNumber = theNum
    End Sub

    Public Sub New(ByVal theForm As System.Windows.Forms.Form, ByVal x As Integer, ByVal y As Integer)
        'Initialization, adds the button to the form
        'Also the FlatStyle line makes sure it looks like a button
        'instead of the pressed-in look after a click
        'Notice the placement algorithm, first button is at (8,8) and
        'They go across and down by 24's, with a width of 24 each
        'Borders overlap, so what? Doesn't hurt anything.
        Me.x = x
        Me.y = y
        Me.Left = 24 * x + 8
        Me.Top = 24 * y + 8
        Me.Width = 24
        Me.Height = 24
        Me.Text = " "
        Me.FlatStyle = FlatStyle.Standard
        parentForm = theForm
        parentForm.Controls.Add(Me)
    End Sub

    Public Sub Clear()
        'Delete the button
        'Starts by removing button from form, then
        'hides it and resets the values for it.
        parentForm.Controls.Remove(Me)
        Me.Hide()
        Me.Left = 0
        Me.Top = 0
        Me.Width = 0
        Me.Height = 0
        Me.FlatStyle = FlatStyle.Standard
    End Sub

    Protected Overrides Sub Finalize()
        'Clears and disposes the button on its deletion
        'I'm not sure if this is necessary, especially the "Me.Dispose()"
        MyBase.Finalize()
        Clear()
        Me.Dispose()
    End Sub

    Public Sub Flag()
        If (Me.FlatStyle = FlatStyle.Standard) Then
            flagged = Not flagged
            If (flagged = True) Then
                Me.Text = "4"
                Me.BackColor = System.Drawing.Color.Yellow
                Me.ForeColor = System.Drawing.Color.Blue
                parentForm.GetGameBoard().score = parentForm.GetGameBoard().score - 1
                parentForm.GetGameBoard().CheckBombs()
            End If
            If (flagged = False) Then
                Me.Text = " "
                Me.BackColor = System.Drawing.Color.Empty
                Me.ForeColor = System.Drawing.Color.Empty
                parentForm.GetGameBoard().score = parentForm.GetGameBoard().score + 1
                parentForm.GetGameBoard().CheckBombs()
            End If
        End If
    End Sub

    Private Sub GameButton_MouseDown(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseDown
        If (parentForm.GetGameBoard().firstClick = False) Then
            parentForm.theTimer.Start()
            parentForm.GetGameBoard().firstClick = True
        End If
        If (parentForm.GetGameBoard().gameOver = True) Then
            resetOnMouseUp = True
            parentForm.GetGameBoard().firstClick = False
        End If
        If (e.Button = MouseButtons.Left) And (flagged = False) And (parentForm.GetGameBoard().gameOver = False) Then
            Me.Uncover()
            If (Me.bomb = False) Then
                parentForm.GetGameBoard().UncoverNearby(x, y)
            End If
        End If
        If (e.Button = MouseButtons.Right) And (parentForm.GetGameBoard().gameOver = False) Then
            Me.Flag()
        End If
    End Sub

    Private Sub GameButton_MouseUp(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles MyBase.MouseUp
        If (resetOnMouseUp = True) Then
            parentForm.AutoNew()
        End If
    End Sub
End Class