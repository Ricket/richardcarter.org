Public Class CustomOptions
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Button2 = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(8, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Height"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(8, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Width"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(8, 72)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 16)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Mines"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(56, 8)
        Me.TextBox1.MaxLength = 2
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.TabIndex = 3
        Me.TextBox1.Text = ""
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(56, 40)
        Me.TextBox2.MaxLength = 2
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.Text = ""
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(56, 72)
        Me.TextBox3.MaxLength = 4
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.TabIndex = 5
        Me.TextBox3.Text = ""
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(168, 8)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(72, 40)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "OK"
        '
        'Button2
        '
        Me.Button2.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Button2.Location = New System.Drawing.Point(168, 56)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(72, 40)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Cancel"
        '
        'CustomOptions
        '
        Me.AcceptButton = Me.Button1
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.CancelButton = Me.Button2
        Me.ClientSize = New System.Drawing.Size(250, 104)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Name = "CustomOptions"
        Me.Text = "Custom"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private theParentForm As frmGame

    Public Sub SetParent(ByVal daParent As frmGame)
        theParentForm = daParent
    End Sub

    Public Sub SetValues(ByVal width As Integer, ByVal height As Integer, ByVal mines As Integer)
        TextBox1.Text = CType(width, String)
        TextBox2.Text = CType(height, String)
        TextBox3.Text = CType(mines, String)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        'OK clicked
        If theParentForm Is Nothing Then
            Me.Close()
        End If
        theParentForm.DoCustom(CType(TextBox1.Text, Integer), CType(TextBox2.Text, Integer), CType(TextBox3.Text, Integer))
        Me.Close()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        'Cancel clicked
        Me.Close()
    End Sub



    Private Sub TextBox1_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TextBox1.Validating
        Dim tempVal1 As Integer = -1
        Try
            tempVal1 = CType(TextBox1.Text, Integer)
        Catch ex As Exception
            e.Cancel = True
            MessageBox.Show("Must be a number from 2-40!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        If tempVal1 <> -1 Then
            If tempVal1 < 2 Or tempVal1 > 99 Then
                e.Cancel = True
                MessageBox.Show("Must be a number from 2-40!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                e.Cancel = False
            End If
        Else
            'Just in case something slips through, somehow...
            e.Cancel = True
        End If
    End Sub

    Private Sub TextBox2_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TextBox2.Validating
        Dim tempVal2 As Integer = -1
        Try
            tempVal2 = CType(TextBox2.Text, Integer)
        Catch ex As Exception
            e.Cancel = True
            MessageBox.Show("Must be a number from 2-40!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        If tempVal2 <> -1 Then
            If tempVal2 < 2 Or tempVal2 > 99 Then
                e.Cancel = True
                MessageBox.Show("Must be a number from 2-40!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                e.Cancel = False
            End If
        Else
            'Just in case something slips through, somehow...
            e.Cancel = True
        End If
    End Sub

    Private Sub TextBox3_Validating(ByVal sender As Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles TextBox3.Validating
        Dim tempVal3 As Integer = -1
        Try
            tempVal3 = CType(TextBox3.Text, Integer)
        Catch ex As Exception
            e.Cancel = True
            MessageBox.Show("Must be a number from 1-1599!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        TextBox3.Text = CType(tempVal3, String)
        If tempVal3 <> -1 Then
            If tempVal3 >= CType(TextBox1.Text, Integer) * CType(TextBox2.Text, Integer) Then
                e.Cancel = True
                MessageBox.Show("Number of mines cannot be greater than or equal to number of spaces!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                If tempVal3 < 1 Or tempVal3 > 1599 Then
                    e.Cancel = True
                    MessageBox.Show("Must be a number from 1-1599!", "Invalid Value", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Else
                    e.Cancel = False
                End If
            End If
        Else
            'Just in case something slips through, somehow...
            e.Cancel = True
        End If
    End Sub
End Class
